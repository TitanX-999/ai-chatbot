import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Brain, 
  EyeOff, 
  BarChart3, 
  MessageSquare, 
  AlertCircle, 
  Send, 
  Loader2, 
  RefreshCcw,
  ShieldCheck,
  ChevronRight
} from 'lucide-react';
import { analyzeMessage, type AnalysisResult } from './services/gemini';

export default function App() {
  const [message, setMessage] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<AnalysisResult | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleAnalyze = async () => {
    if (!message.trim()) return;
    
    setLoading(true);
    setError(null);
    try {
      const data = await analyzeMessage(message);
      setResult(data);
    } catch (err) {
      setError('Something went wrong during the analysis. Please try again.');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const reset = () => {
    setMessage('');
    setResult(null);
    setError(null);
  };

  return (
    <div className="min-h-screen bg-bento-bg text-bento-text font-sans p-8 flex flex-col gap-6 selection:bg-bento-accent/30 selection:text-white">
      {/* Header */}
      <header className="flex justify-between items-end border-b border-bento-border pb-4">
        <div className="text-2xl font-extrabold tracking-tighter uppercase italic">
          Subtext<span className="text-bento-accent">Intelligence</span>
        </div>
        <motion.div 
          animate={{ opacity: [0.5, 1, 0.5] }}
          transition={{ duration: 2, repeat: Infinity }}
          className="bg-bento-accent/10 border border-bento-accent text-bento-accent px-3 py-1 rounded-full text-[10px] uppercase tracking-widest font-bold"
        >
          Analysis Pulse Active
        </motion.div>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 flex-1">
        {/* Input Box - span 3 */}
        <section className="md:col-span-3 bg-bento-card border border-bento-border rounded-2xl p-6 flex flex-col relative overflow-hidden">
          <div className="flex items-center gap-2 font-mono text-[10px] uppercase tracking-widest text-bento-muted mb-4">
            <span className="w-1.5 h-1.5 bg-bento-accent rounded-full shrink-0" />
            Source Message
          </div>
          <textarea
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            placeholder="Paste the message for cold analysis..."
            className="w-full h-32 bg-transparent border-none focus:ring-0 p-0 text-lg leading-relaxed text-bento-text placeholder-bento-muted/30 italic resize-none"
          />
          <div className="flex justify-between items-center mt-4">
            <span className="text-[10px] font-mono text-bento-muted/50">
              {message.length} CHARS
            </span>
            <div className="flex gap-2">
              {result && (
                <button
                  onClick={reset}
                  className="p-2 text-bento-muted hover:text-bento-text transition-colors"
                >
                  <RefreshCcw className="w-4 h-4" />
                </button>
              )}
              <button
                onClick={handleAnalyze}
                disabled={loading || !message.trim()}
                className="px-6 py-2 bg-bento-accent text-white rounded-lg font-bold text-xs uppercase tracking-widest hover:brightness-110 active:scale-95 transition-all disabled:opacity-20 disabled:grayscale"
              >
                {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : "Run Analysis"}
              </button>
            </div>
          </div>
        </section>

        <AnimatePresence mode="wait">
          {error && (
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="md:col-span-3 p-4 bg-red-500/10 border border-red-500/20 text-red-500 rounded-xl flex items-center gap-2"
            >
              <AlertCircle className="w-4 h-4" />
              <span className="text-xs">{error}</span>
            </motion.div>
          )}

          {result && !loading && (
            <>
              {/* Primary Analysis - span 2 */}
              <motion.section 
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="md:col-span-2 bg-bento-card border border-bento-border rounded-2xl p-6"
              >
                <div className="flex items-center gap-2 font-mono text-[10px] uppercase tracking-widest text-bento-muted mb-4">
                  <span className="w-1.5 h-1.5 bg-bento-accent rounded-full shrink-0" />
                  🧠 Baseline Analysis
                </div>
                <p className="text-bento-text font-light leading-relaxed">
                  {result.analysis.split(/(\w+)/).map((word, i) => {
                    // Highlight logic could be added here if we had keyword detection
                    return word;
                  })}
                </p>
              </motion.section>

              {/* Honesty Score - span 1 */}
              <motion.section 
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 }}
                className="bg-bento-card border border-bento-border rounded-2xl p-6 flex flex-col items-center justify-center text-center"
              >
                <div className="flex items-center gap-2 font-mono text-[10px] uppercase tracking-widest text-bento-muted mb-6 w-full">
                  <span className="w-1.5 h-1.5 bg-bento-accent rounded-full shrink-0" />
                  📊 Sincerity
                </div>
                <div className="text-7xl font-extrabold tracking-tighter text-yellow-500 leading-none mb-2">
                  {result.honestyScore}%
                </div>
                <div className="text-[10px] text-bento-muted uppercase tracking-[0.2em] font-bold mb-4">
                  Honesty Confidence
                </div>
                <p className="text-[11px] text-bento-muted leading-relaxed px-4">
                  {result.honestyExplanation}
                </p>
              </motion.section>

              {/* Hidden Meaning - span 2 */}
              <motion.section 
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 }}
                className="md:col-span-2 bg-bento-card border border-bento-border rounded-2xl p-6"
              >
                <div className="flex items-center gap-2 font-mono text-[10px] uppercase tracking-widest text-bento-muted mb-4">
                  <span className="w-1.5 h-1.5 bg-bento-accent rounded-full shrink-0" />
                  🎭 Latent Meaning
                </div>
                <ul className="space-y-4">
                  {result.hiddenMeaning.split('.').filter(s => s.trim()).map((sentence, i) => (
                    <li key={i} className="flex gap-4 group">
                      <span className="text-bento-accent text-lg leading-none shrink-0 group-hover:translate-x-1 transition-transform">→</span>
                      <p className="text-sm text-bento-text/80 leading-relaxed italic">
                        {sentence.trim()}.
                      </p>
                    </li>
                  ))}
                </ul>
              </motion.section>

              {/* Suggested Reply - span 1 */}
              <motion.section 
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3 }}
                className="bg-green-500/5 border border-green-500/20 rounded-2xl p-6 flex flex-col"
              >
                <div className="flex items-center gap-2 font-mono text-[10px] uppercase tracking-widest text-green-500/60 mb-6">
                  <span className="w-1.5 h-1.5 bg-green-500 rounded-full shrink-0" />
                  💬 Optimal Response
                </div>
                <div className="bg-black/20 p-4 rounded-xl border-l-[3px] border-green-500/50 mb-4 group cursor-pointer hover:bg-black/30 transition-colors"
                     onClick={() => navigator.clipboard.writeText(result.suggestedReply)}>
                  <p className="text-green-500 font-medium leading-relaxed italic text-sm">
                    "{result.suggestedReply}"
                  </p>
                </div>
                <button 
                  onClick={() => navigator.clipboard.writeText(result.suggestedReply)}
                  className="mt-auto flex items-center gap-1 text-[9px] uppercase tracking-widest font-bold text-green-500/40 hover:text-green-500 transition-colors"
                >
                  Copy to Clipboard <ChevronRight className="w-3 h-3" />
                </button>
              </motion.section>
            </>
          )}
        </AnimatePresence>
      </div>

      <footer className="text-[10px] text-bento-muted/40 text-center uppercase tracking-widest pt-4">
        ⚠️ AI-based linguistic pattern interpretation. Psychological context varies by context.
      </footer>
    </div>
  );
}


