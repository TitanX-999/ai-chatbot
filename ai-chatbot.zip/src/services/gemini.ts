import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

export interface AnalysisResult {
  analysis: string;
  hiddenMeaning: string;
  honestyScore: number;
  honestyExplanation: string;
  suggestedReply: string;
}

export async function analyzeMessage(message: string): Promise<AnalysisResult> {
  const result = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: `Analyze the following message for hidden meanings, emotional intent, and honesty level. 
    User Input: ${message}`,
    config: {
      systemInstruction: `You are an expert in human communication, psychology, and text analysis. 
      Your task is to analyze a message and detect possible hidden meanings, emotional intent, and honesty level.
      
      Strict Instructions:
      - Be insightful but NOT overly certain (avoid absolute claims like “this is a lie”)
      - Analyze tone, wording, and context clues
      - Identify possible hidden intentions
      - Keep explanations short and clear
      - Be realistic and human-like, not robotic
      - Do NOT make harmful assumptions or accusations`,
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          analysis: {
            type: Type.STRING,
            description: "What the message suggests on the surface.",
          },
          hiddenMeaning: {
            type: Type.STRING,
            description: "What the person might really mean.",
          },
          honestyScore: {
            type: Type.NUMBER,
            description: "A score from 0 to 100 representing the perceived honesty.",
          },
          honestyExplanation: {
            type: Type.STRING,
            description: "A brief explanation for the honesty score.",
          },
          suggestedReply: {
            type: Type.STRING,
            description: "A smart, confident response the user can send.",
          },
        },
        required: ["analysis", "hiddenMeaning", "honestyScore", "honestyExplanation", "suggestedReply"],
      },
    },
  });

  try {
    const data = JSON.parse(result.text || "{}");
    return data;
  } catch (e) {
    throw new Error("Failed to parse analysis result");
  }
}
